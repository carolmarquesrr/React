import React from 'react';

const HelloWorld = ({name}) => {
  const helloooo = name ? `Hello, ${name}.` : 'Hello, stranger.';

  return (
    <h1>{helloooo}</h1>
  );
};

export default HelloWorld;
