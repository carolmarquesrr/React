
import React, { useState } from 'react';

const PasswordInput = () => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isFocused, setIsFocused] = useState(false);

  const handleInputChange = (event) => {
    setPassword(event.target.value);
  };

  const handleFocus = () => {
    setIsFocused(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

/* condicoes pra ver se a senha é forte */

  const getPasswordStrength = () => {
    const length = password.length;

    if (length === 0) {
      return "";
    } else if (length > 10) {
      return 'Password Forte';
    } else if (length > 6) {
      return 'Password Média';
    } else {
      return 'Password Fraca';
    }
  };
/* ternario ns botao p mostrar ou n */


/* ROLE = "feedback" renderizado */
  return (
    <div>
      <input
        type={showPassword ? 'text' : 'password'}
        value={password}
        onChange={handleInputChange}
        onFocus={handleFocus}
        onBlur={handleBlur}
        role="input"
      />
      
            {isFocused && getPasswordStrength() !== '' && (
         <p role="feedback">{getPasswordStrength()}</p>
      )}
      <button onMouseDown={toggleShowPassword} onMouseUp={toggleShowPassword}>
        Mostrar
      </button>
    </div>
  );
};

export default PasswordInput; 


