import logo from './logo.svg';
import './App.css';
import PasswordInput from './PasswordInput';

function App() {
  return (
    <div className="App">
      <PasswordInput />

    </div>
  );
}

export default App;
