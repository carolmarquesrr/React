import React, { useState } from "react";

export default function TwoLists() {
  const [nomes, setNomes] = useState([]);
  const [apelidos, setApelidos] = useState([]);
  const [state, setState] = useState("");
  const [nomeCompleto, setNomeCompleto] = useState("");

  const handleInput = (e) => {
    setState(e.target.value);
  };

  const handleAddName = () => {
    setNomes((prvNomes) => [...prvNomes, state]);
    setState("");
  };

  const handleAddApelido = () => {
    setApelidos((prvApelidos) => [...prvApelidos, state]);
    setState("");
  };

  const handleGerar = () => {
    const nomeAle = Math.floor(Math.random() * nomes.length);
    const apelidoAle = Math.floor(Math.random() * apelidos.length);
    setNomeCompleto(`${nomes[nomeAle]} ${apelidos[apelidoAle]}`);
  };

  return (
    <div>
      <div role="list">
        {nomes.map((ele) => (
          <span role="listitem">{ele}</span>
        ))}
      </div>
      <div role="list">
        {apelidos.map((ele) => (
          <span role="listitem">{ele}</span>
        ))}
      </div>
      {nomeCompleto && <p role="name">{nomeCompleto}</p>}
      <div>
        <input type="text" value={state} onChange={(e) => handleInput(e)} />
        <button onClick={() => handleAddName()}>Adicionar nome</button>
        <button onClick={() => handleAddApelido()}>Adicionar apelido</button>
      </div>
      <button onClick={() => handleGerar()}>Gerar Nome</button>
    </div>
  );
}
