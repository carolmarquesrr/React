import TwoLists from "./TwoLists";

function App() {
  return (
    <div className="App">
      <TwoLists />
    </div>
  );
}

export default App;
